# tableau_integration

This repo contains code of integrating machine learning model with tableau dashboard using TabPy. Detailed steps can be found in my article [here](https://towardsdatascience.com/integrating-machine-learning-models-with-tableau-b484c0e099c5)

### Result

![alttext](https://github.com/JaswanthBadvelu/tableau_integration/blob/main/Result.png)


